const express = require('express');
const router = express.Router();

const User = require('../models/User');
const passport= require('passport');

router.get('/users/signin', (req, res) =>{
    res.render('users/signin');
});

router.post('/users/signin', passport.authenticate('local', {
    successRedirect: '/about',
    failureRedirect: '/users/signin',
    failureFlash: true
}))

router.get('/users/signup', (req, res) =>{
    res.render('users/signup');
});

router.post('/users/signup', async (req, res) =>{
    const { name, lastname, email, password, confirm_password} = req.body;
    const errors = [];
    console.log(req.body)
    if (
        name.length <= 0 ||
        email.length <= 0 ||
        lastname.lenght <= 0 ||
        password.length <= 0 ||
        confirm_password.length <= 0
      ) {
        errors.push({
          text: "Por favor, verifique que todos los campos estén llenos.",
        });
      }
    if(password != confirm_password) {
        errors.push({text: '¡Las contraseñas no coinciden!'});
    }
    if (password.lenght < 4) {
        errors.push({text: '¡La contraseña debe ser mayor de 4 caracteres!'});
    }
    if(errors.length>0){
        res.render('users/signup', {errors, name, lastname, email, password, confirm_password});
    } else {
        const newUser = new User({name, lastname, email, password});
        const emailUser = await User.findOne({email: email});
        if(emailUser){
            req.flash('error_msg', 'El email ingresado ya esta siendo utilizando');
            res.redirect('/users/signup');
        }

        newUser.password = await newUser.encryptPassword(password);
        await newUser.save();
        req.flash('success_msg', "¡Creaste una nueva cuenta!");
        res.redirect('/users/signin')
    }
});

router.get('/users/logout', (req, res, next) => {
    req.logOut(function(err) {
      if (err) {
        return next(err);
      }
      res.redirect('/');
    });
  });
  
module.exports = router;