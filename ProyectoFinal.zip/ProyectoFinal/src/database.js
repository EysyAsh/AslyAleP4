const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/ProyectoFinal')
    .then(db => console.log('Se conecto a la BD'))
    .catch(err => console.error(err));